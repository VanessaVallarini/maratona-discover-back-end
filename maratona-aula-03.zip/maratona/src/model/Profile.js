//criando um objeto que será exibido na página profile.ejs
let data = {
    name: "Ichikawa",
    avatar: "https://avatars.githubusercontent.com/u/34397262?v=4",
    "monthly-budget": 3000,
    "days-per-week": 5,
    "hours-per-day": 5,
    "vacation-per-year": 4,
    "value-hour": 75,
};

//criando um objeto do tipo get e exportando ele
//utilizando o update para atualizar os dados
module.exports = {
    get() {
        return data;
    },
    update(newData) {
        data = newData;
    }
}
