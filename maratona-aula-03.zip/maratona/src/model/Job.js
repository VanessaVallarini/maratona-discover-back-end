const { update } = require("./Profile");

let data = [
    {
        id: 1,
        name: "Pizzaria Guloso",
        "daily-hours": 2,
        "total-hours": 1,
        created_at: Date.now()//atribuindo hora de hoje em milissegundos
    },
    {
        id: 2,
        name: "OneTwo Project",
        "daily-hours": 3,
        "total-hours": 47,
        created_at: Date.now()//atribuindo hora de hoje em milissegundos
    }
];

module.exports = {
    get() {
        return data
    },
    update(newJob) {
        data = newJob
    },
    delete(id) {
        //filter é o mesmo que map, find, forEach, a diferença é que quando ele encontra o recurso ele remove esse recurso do array
        data = data.filter(job => Number(job.id) !== Number(id))
    }
}