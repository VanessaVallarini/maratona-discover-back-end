//importando os dados de job
const Job = require('../model/Job')
const JobUtils = require('../utils/JobUtils')
const Profile = require('../model/Profile')

module.exports = {
    create(req, res) {
        return res.render("job")
    },

    save(req, res) {
        const jobs = Job.get()
        //pegando o último ID, se o resultado for -1 (valor inexistente no índice de um array) eu atribuo ID 1
        const lastId = jobs[jobs.length - 1]?.id || 0;
        jobs.push({ //empurrando/armazenando os dados vindos do form html para o array de jobs
            id: lastId + 1,
            name: req.body.name,
            "daily-hours": req.body["daily-hours"],
            "total-hours": req.body["total-hours"],
            created_at: Date.now()//atribuindo hora de hoje em milissegundos
        })
        return res.redirect('/')
    },

    show(req, res) {
        const jobId = req.params.id //recebendo o id do job através do req
        const jobs = Job.get()

        //find é muito parecido com foreach e map
        //forEach vai percorrer todos os elementos
        //mas retorna um novo array
        //find procura algo dentro do array
        //se o id do job for igual ao id do job do req, armazena na const job
        const job = jobs.find(job => Number(job.id) === Number(jobId))
        if (!job) {
            return res.send('Job not found!')
        }
        const profile = Profile.get()
        job.budget = JobUtils.calculateBudget(job, profile["value-hour"])
        return res.render("job-edit", { job })
    },

    update(req, res) {
        const jobId = req.params.id //recebendo o id do job através do req
        const jobs = Job.get()

        //find é muito parecido com foreach e map
        //forEach vai percorrer todos os elementos
        //mas retorna um novo array
        //find procura algo dentro do array
        //se o id do job for igual ao id do job do req, armazena na const job
        const job = jobs.find(job => Number(job.id) === Number(jobId))
        if (!job) {
            return res.send('Job not found!')
        }

        //atualizando o job encontrado através do find
        const updatedJob = {
            ...job,//espalhando o job eu garanto que o id e o created_at: Date.now() se mantenham mesmo que os campos abaixo venham preenchidos vazio no update
            name: req.body.name,
            "total-hours": req.body["total-hours"],
            "daily-hours": req.body["daily-hours"],
        }

        //atualizando o Job Model, cujo tenha o mesmo ID do job que está na variável updatedJob
        const newJobs = jobs.map(job => {
            if (Number(job.id) === Number(jobId)) {
                job = updatedJob
            }
            return job
        })
        Job.update(newJobs)
        res.redirect('/job/' + jobId)
    },

    delete(req, res) {
        const jobId = req.params.id //recebendo o id do job através do req
        Job.delete(jobId)
        return res.redirect('/')
    }
}