//função require: estou chamando o pacote express da nossa pasta node_modules
const express = require('express');

//funcionalidade que retornará um objeto
const routes = express.Router()

//a base dos arquivos html
//ejs já lê o __dirname, porém, ele não a encontrou, por isso vamos utilizar essa variável 
//cuja contém o caminho da pasta vews
//se a pasta views estivesse fora do src ele encontraria
const views = __dirname + "/views/"

//criando um objeto que será exibido na página profile.ejs
const Profile = {
    data: {
        name:"Ichikawa",
        avatar: "https://avatars.githubusercontent.com/u/34397262?v=4",
        "monthly-budget": 3000,
        "days-per-week": 5,
        "hours-per-day": 5,
        "vacation-per-year": 4,
        "value-hour": 75
    },

    controllers: {
        index(req, res){
            return res.render(views + "profile", { profile: Profile.data })
        },

        //faz o calculo do custo de hora
        update(req, res){
            //req.bory para pegar os dados inputados pelo usuário
            const data = req.body
            //definir quantas semanas tem em um ano: 52
            const weeksPerYear = 52
            //remover as semanas de férias do ano, para pegar quantas semanas tem em 1 mês
            const weeksPerMonth = (weeksPerYear - data["vacation-per-year"] ) / 12
            //quantas horas por semana estou trabalhando
            const weekTotalHours = data["hours-per-day"] * data["days-per-week"]
            //total de horas trabalhadas no mês
            const monthlyTotalHours = weekTotalHours * weeksPerMonth
            //qual será o valor da minha hora?
            const valueHour = data["monthly-budget"] / monthlyTotalHours

            Profile.data = {
                ...Profile.data,
                ...req.body,
                "value-hour": valueHour
            }

            return res.redirect('/profile')
        }
    }
}

const Job = {
    data: [
        {
            id: 1, 
            name: "Pizzaria Guloso",
            "daily-hours": 2,
            "total-hours": 1,
            created_at: Date.now(),//atribuindo hora de hoje em milissegundos
        },
        {
            id: 2, 
            name: "OneTwo Project",
            "daily-hours": 3,
            "total-hours": 47,
            created_at: Date.now(),//atribuindo hora de hoje em milissegundos
        }
    ],

    controllers: {
        index(req, res) {
            //map tem a mesma função do forEach, porém, consigo retornar um objeto novo
            const updateJobs = Job.data.map((job) => {
                //ajustes no job - calculo de tempo restante
                const remaining = Job.services.remainingDays(job)
                //retornando o status do job, se for dia == 0 retorna done se não, em progresso
                const status = remaining <= 0 ? 'done' : 'progress'
                
                return {
                    ...job,
                    remaining,
                    status,
                    budget: Job.services.calculateBudget(job, Profile.data["value-hour"]) //valor minha hora * total de horas do projeto
                }
            })
            return res.render(views + "index", { jobs: updateJobs })//esse jobs é o que vai pro index.ejs
        },

        create(req, res){
            return res.render(views + "job")
        },

        save(req, res) {
            //pegando o último ID, se o resultado for -1 (valor inexistente no índice de um array) eu atribuo ID 1
            const lastId = Job.data[Job.data.length -1]?.id || 0;
            Job.data.push({ //empurrando/armazenando os dados vindos do form html para o array de jobs
                id: lastId + 1, 
                name: req.body.name,
                "daily-hours": req.body["daily-hours"],
                "total-hours": req.body["total-hours"],
                created_at: Date.now()//atribuindo hora de hoje em milissegundos
            })
            return res.redirect('/')
        },

        show(req, res){
            const jobId = req.params.id //recebendo o id do job através do req
            //find é muito parecido com foreach e map
            //forEach vai percorrer todos os elementos
            //mas retorna um novo array
            //find procura algo dentro do array
            //se o id do job for igual ao id do job do req, armazena na const job
            const job = Job.data.find(job => Number(job.id) === Number(jobId))
            if(!job){
                return res.send('Job not found!')
            }
            job.budget = Job.services.calculateBudget(job, Profile.data["value-hour"])
            return res.render(views + "job-edit", { job })
        },

        update(req, res){
            const jobId = req.params.id //recebendo o id do job através do req
            //find é muito parecido com foreach e map
            //forEach vai percorrer todos os elementos
            //mas retorna um novo array
            //find procura algo dentro do array
            //se o id do job for igual ao id do job do req, armazena na const job
            const job = Job.data.find(job => Number(job.id) === Number(jobId))
            if(!job){
                return res.send('Job not found!')
            }

            //atualizando o joob encontrado através do find
            const updatedJob = {
                ...job,//espalhando o job eu garanto que o id e o created_at: Date.now() se mantenham mesmo que os campos abaixo venham preenchidos vazio no update
                name: req.body.name,
                "total-hours": req.body["total-hours"],
                "daily-hours": req.body["daily-hours"],
            }

            //apenas validando que o job que está sendo alterado é o mesmo que foi acessado
            Job.data = Job.data.map(job => {
                if(Number(job.id) === Number(jobId)){
                    job = updatedJob
                }

                return job
            })

            res.redirect('/job/' + jobId)
        },

        delete(req, res){
            const jobId = req.params.id //recebendo o id do job através do req
            //filter é o mesmo que map, find, forEach, a diferença é que quando ele encontra o recurso ele remove esse recurso do array
            Job.data = Job.data.filter(job => Number(job.id) !== Number(jobId))

            return res.redirect('/')
        }
    },

    services: {
        remainingDays(job){
            //dias que faltam
            //toFixed retorna o valor inteiro
            const remainingDays = (job["total-hours"] / job["daily-hours"]).toFixed()
            //data atual e retirar os dias que já passaram
            const createdDate = new Date(job.created_at)
            //dia de criação + 20 dias pra frente, quero saber a data final do projeto
            //dueDay é o dia do vencimento do projeto
            const dueDay = Number(createdDate.getDate()) + Number(remainingDays)//toFixed tras o número em string, aqui estamos retornando para int
            const dueDateInMs = createdDate.setDate(dueDay)//criando uma nova data a partir da data atual
            //tirar da data do futuro os dias que faltam baseado na data de hoje
            const timeDiffInMs = dueDateInMs - Date.now()
            //transformar milissegundos em dias
            const dayInMs = 1000 * 60 * 60 * 24
            //arredondando para baixo a diferença de dias
            const dayDiff = Math.floor(timeDiffInMs / dayInMs)
            //restam x dias
            return dayDiff
        },

        calculateBudget: (job, valueHour) => valueHour * job["total-hours"] //valor minha hora * total de horas do projeto
    }
}

//passando pelo motor engine do express (ejs)
//Deixamos de usar sendFile e passamos a usar o render porque
//não estamos mais enviando o arquivo e sim renderizando
routes.get('/', Job.controllers.index);
routes.get('/job', Job.controllers.create)
//o req está recebendo os dados que imputei no formulário do front:
//{ name: 'Discover', 'daily-hours': '9', 'total-hours': '9' }
routes.post('/job', Job.controllers.save)
//pegando o ID através do req
routes.get('/job/:id', Job.controllers.show)
//passando o objeto criado acima
routes.post('/job/:id', Job.controllers.update)
routes.post('/job/delete/:id', Job.controllers.delete)
//e o motor engine substitui os dados do HTML profile.ejs por este objeto
routes.get('/profile', Profile.controllers.index)
routes.post('/profile', Profile.controllers.update)
module.exports = routes;