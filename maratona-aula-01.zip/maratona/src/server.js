//função require: estou chamando o pacote express da nossa pasta node_modules
const express = require("express")

//criando o meu servidor executendo o pacote do express
const server = express()

//pegando a saído do arquivo routes.js
const routes = require("./routes") 

//acessando a página index. 
//Como ainda não criamos as rotas, precisamos setar a página index através do request, response
//abaixo enviamos apenas um OI para testar
//server.get('/', (requeste, response) => {
    //return response.send('OI')
//})


//caminhos absolutos e caminhos relativos para acessar os arquivos do nosso projeto

//caminho absoluto
//essa não é uma boa prática
//server.get('/', (requeste, response) => {
    //return response.sendFile("e/CURSOS/Maratona/maratona/index.html")
//})

//caminho relativo
//./ significa a pasta src, onde meu servidor é executado
//para acessar um arquivo fora da pasta src devia ser ../
//server.get('/', (requeste, response) => {
    //return response.sendFile('./')
//})

//__dirname: corresponde ao caminho absoluto
//server.get('/', (requeste, response) => {
    //return response.sendFile(__dirname + 'views/index.html')
//})

//criando as rotas após jogarmos todas as imagens, scipts e css na pasta public
//essa função é considerada um midware, pois, fica entre a chamada da página principal
//o / e o recurso de request/ response 
//ela serve para habilitar os arquivos estáticos
//server.use(express.static("public"))

//server.get('/', (requeste, response) => {
    //return response.sendFile(__dirname + 'views/index.html')
//})

//utilizando a rota criada no arquivo Routes
//server.use(routes)

//setando uma configuração
//express já tem uma idéia de template engine e estamos reutilizando 'view engine'
//ejs faz um processamento do html olhando tudo o que tem <% (contexto)
//todo contexto contexto será explorado com javascript e vai ser refeito em HTML puro
server.set('view engine', 'ejs')

//habilitar arquivos estáticos
server.use(express.static("public"))

//utilizando a rota criada no arquivo Routes
server.use(routes)


//Funcionalidade do express para simular o nosso servidor em uma determinada porta
server.listen(3000, () => console.log('rodando'))
