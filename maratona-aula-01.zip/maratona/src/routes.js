//função require: estou chamando o pacote express da nossa pasta node_modules
const express = require('express');

//funcionalidade que retornará um objeto
const routes = express.Router()

//retornando o objeto index.html
//routes.get('/', (req, res) =>  {
    //return res.sendFile(__dirname + "views/index.html")
//})

//caso o usuário digite index.html ele é redirecionada para o /
//routes.get('/index.html', (req, res) =>  {
    //return res.redirect(‘/’)
//})

//retornando o objeto que é a rota
//module.exports = routes;

//a base dos arquivos html
//ejs já lê o __dirname, porém, ele não a encontrou, por isso vamos utilizar essa variável 
//cuja contém o caminho da pasta vews
//se a pasta views estivesse fora do src ele encontraria
const views = __dirname + "/views/"

//criando um objeto que será exibido na página profile.ejs
const profile = {
    name:"Ichikawa",
    avatar: "https://avatars.githubusercontent.com/u/34397262?v=4",
    "monthly-budget": 3000,
    "days-per-week": 5,
    "hours-per-day": 5,
    "vacation-per-year": 4
}

//passando pelo motor engine do express (ejs)
//Deixamos de usar sendFile e passamos a usar o render porque
//não estamos mais enviando o arquivo e sim renderizando
routes.get('/', (req, res) =>  res.render(views + "index"))
routes.get('/job', (req, res) =>  res.render(views + "job"))
routes.get('/job/edit', (req, res) =>  res.render(views + "job-edit"))

//passando o objeto criado acima
//e o motor engine substitui os dados do HTML profile.ejs por este objeto
routes.get('/profile', (req, res) =>  res.render(views + "profile", { profile }))


module.exports = routes;